# Insert your TOGETHER_API_KEY and remove '.example' from the file name 
TOGETHER_API_KEY="e1eaa5d9f2e87e0a96f6550e0e0651cee45252c9088eb7eabd9ee8130855eb44"